// index.js
// 获取应用实例
const app = getApp()

Page({
  //=========数据域==========
  data: {
    tmpImageUrl: '',
    resultText: '',
    resObj:null
  },

  //==========函数区==========
  requestAI() {
    let that = this;
    wx.uploadFile({
      url: 'http://192.168.124.24/upload', //仅为示例，非真实的接口地址
      filePath: that.data.tmpImageUrl,
      name: 'files',
      formData: {
        'user': 'test'
      },
      success(res) {
        console.log(res);
        let resObj = JSON.parse(res.data);
        console.log(resObj);
        
        that.setData({
          resObj:resObj,
          resultText: JSON.stringify(resObj.pinyin[0])
        })
      },
      complete() {
        wx.hideLoading({
          success: (res) => {},
        })
      }
    })
  },


  chooseImage() {
    let that = this;
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      camera: 'back',
      success(res) {
        console.log(res)
        console.log(res.tempFiles[0].tempFilePath)
        console.log(res.tempFiles[0].size)
        that.setData({
          tmpImageUrl: res.tempFiles[0].tempFilePath
        });
        wx.showLoading({
          title: '识别中',
        })
        that.requestAI();
      },
      fail(res) {
        console.log(res)
      }
    })
  },



  //==========生命周期区==========
  //页面第一次加载时执行
  onLoad() {

  },
  //页面显示时执行
  onShow() {

  }
})